Scripts to program NMEA2000GW interface module:

1- can-boot.sh
Program bootcode in NMEA2000 module using stk500 tool on port ttyUSB4

2- can-flash.sh
Upload firmware in NMEA2000 module connected on port ttyAMA0
